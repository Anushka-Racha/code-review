# CodeRefine - AI-Powered Code Reviewer & Optimizer

CodeRefine is a lightweight, AI-powered code review assistant built with FastAPI and React. It uses local LLMs (via Ollama) to analyze code, suggest improvements, detect security issues, and provide optimized versions of your code.

## Features

- **AI Code Review**: Detects inefficient loops, bad naming, redundant logic, and poor structure.
- **Optimization Suggestions**: Provides time complexity hints, cleaner alternatives, and better data structures.
- **Security Check**: Identifies hardcoded credentials, SQL injection risks, and unsafe practices.
- **Complexity Estimation**: Estimates time and space complexity of your code.
- **Local AI**: Runs entirely on your machine using Ollama (no external API keys required).

## Tech Stack

- **Backend**: Python, FastAPI, Ollama (LLM)
- **Frontend**: React 19, Vite, Tailwind CSS, Framer Motion, Lucide React

## Getting Started

### Prerequisites

- Python 3.10+
- Node.js 18+
- [Ollama](https://ollama.com/) installed and running

### Installation

1. **Clone the repository**

2. **Set up the Backend**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up the Frontend**
   ```bash
   cd frontend
   npm install
   ```

### Running the Application

1. **Start Ollama** (for local AI)
   Make sure Ollama is running with a model:
   ```bash
   ollama run llama3
   ```

2. **Start the Backend**
   ```bash
   uvicorn main:app --reload
   ```

3. **Start the Frontend**
   ```bash
   cd frontend
   npm run dev
   ```

4. Open your browser at `http://localhost:5173`.

## Project Structure

- `main.py`: FastAPI backend handling code analysis.
- `frontend/`: React frontend application.
- `test_code.py`: Sample code for testing the application.

## Demo Mode

If Ollama is not running, the application will automatically switch to **Demo Mode** with basic code analysis so you can still test the UI.

## License

MIT