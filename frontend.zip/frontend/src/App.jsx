import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Code2, 
  Zap, 
  Shield, 
  Activity, 
  Copy, 
  Check, 
  Cpu, 
  AlertTriangle, 
  ArrowRight,
  Sparkles,
  Terminal
} from 'lucide-react';

const CodeReviewApp = () => {
  const [code, setCode] = useState('');
  const [result, setResult] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [mode, setMode] = useState('demo');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    checkStatus();
  }, []);

  const checkStatus = async () => {
    try {
      const res = await fetch('http://localhost:8000/api/status');
      const data = await res.json();
      setMode(data.mode);
    } catch (e) {
      setMode('demo');
    }
  };

  const analyzeCode = async () => {
    if (!code.trim()) {
      setError('Please enter some code to analyze');
      return;
    }

    setIsAnalyzing(true);
    setError('');
    setResult(null);

    try {
      const res = await fetch('http://localhost:8000/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code })
      });
      
      if (!res.ok) throw new Error('Analysis failed');
      
      const data = await res.json();
      setResult(data);
      setMode(data.mode || 'demo');
    } catch (err) {
      setError(err.message || 'Failed to analyze code');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const copyToClipboard = () => {
    if (result?.improved_code) {
      navigator.clipboard.writeText(result.improved_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-emerald-400';
    if (score >= 70) return 'text-amber-400';
    return 'text-rose-400';
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500/30">
      {/* Header */}
      <header className="border-b border-slate-800/50 backdrop-blur-sm sticky top-0 z-50 bg-slate-950/80">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/10 rounded-lg">
              <Code2 className="w-8 h-8 text-indigo-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                CodeRefine
              </h1>
              <p className="text-xs text-slate-500">AI-Powered Code Reviewer</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 ${
              mode === 'gemini' 
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
            }`}>
              <Cpu className="w-3 h-3" />
              {mode === 'gemini' ? 'GEMINI ACTIVE' : 'DEMO MODE'}
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Terminal className="w-5 h-5 text-slate-400" />
                Input Code
              </h2>
              <span className="text-xs text-slate-500">Paste your code below</span>
            </div>
            
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl opacity-0 group-hover:opacity-20 transition duration-500"></div>
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="def calculate_sum(numbers):&#10;    total = 0&#10;    for i in numbers:&#10;        total += i&#10;    return total"
                className="relative w-full h-[400px] bg-slate-900/50 border border-slate-800 rounded-xl p-4 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-none"
                spellCheck="false"
              />
            </div>

            <button
              onClick={analyzeCode}
              disabled={isAnalyzing}
              className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Analyzing Code...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Analyze & Optimize
                </>
              )}
            </button>

            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-sm"
              >
                {error}
              </motion.div>
            )}
          </motion.div>

          {/* Output Section */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-400" />
                Optimized Code
              </h2>
              {result && (
                <div className={`flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 border ${
                  result.score >= 90 ? 'border-emerald-500/30' : 
                  result.score >= 70 ? 'border-amber-500/30' : 'border-rose-500/30'
                }`}>
                  <span className="text-xs text-slate-400">Score:</span>
                  <span className={`font-bold ${getScoreColor(result.score)}`}>
                    {result.score}/100
                  </span>
                </div>
              )}
            </div>

            {!result ? (
              <div className="h-[400px] border-2 border-dashed border-slate-800 rounded-xl flex flex-col items-center justify-center text-slate-500">
                <Code2 className="w-16 h-16 mb-4 opacity-20" />
                <p>Results will appear here</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Improved Code */}
                <div className="relative group">
                  <div className="absolute top-3 right-3 z-10">
                    <button
                      onClick={copyToClipboard}
                      className="p-2 bg-slate-800/80 hover:bg-slate-700 rounded-lg transition-colors"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <pre className="w-full bg-slate-900 border border-slate-800 rounded-xl p-4 font-mono text-sm overflow-auto h-[200px]">
                    <code className="text-emerald-300">{result.improved_code}</code>
                  </pre>
                </div>

                {/* Analysis Grid */}
                <div className="grid gap-4">
                  {/* Issues */}
                  <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
                    <h3 className="text-sm font-semibold text-rose-400 mb-2 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" />
                      Issues Detected
                    </h3>
                    <ul className="space-y-1">
                      {result.issues?.map((issue, i) => (
                        <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                          <span className="text-rose-500">•</span>
                          {issue}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Optimizations */}
                  <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
                    <h3 className="text-sm font-semibold text-emerald-400 mb-2 flex items-center gap-2">
                      <Zap className="w-4 h-4" />
                      Optimizations
                    </h3>
                    <ul className="space-y-1">
                      {result.optimizations?.map((opt, i) => (
                        <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                          <span className="text-emerald-500">•</span>
                          {opt}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Security & Complexity */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
                      <h3 className="text-sm font-semibold text-blue-400 mb-2 flex items-center gap-2">
                        <Shield className="w-4 h-4" />
                        Security
                      </h3>
                      <ul className="space-y-1">
                        {result.security_concerns?.map((s, i) => (
                          <li key={i} className="text-sm text-slate-300">{s}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
                      <h3 className="text-sm font-semibold text-purple-400 mb-2 flex items-center gap-2">
                        <Activity className="w-4 h-4" />
                        Complexity
                      </h3>
                      <p className="text-sm font-mono text-purple-300">{result.complexity}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </main>
    </div>
  );
};

export default CodeReviewApp;