# Sample Code for Testing CodeRefine

# Example 1: Inefficient Loop
def find_max_slow(numbers):
    max_val = 0
    for i in range(len(numbers)):
        if numbers[i] > max_val:
            max_val = numbers[i]
    return max_val

# Example 2: Redundant Logic
def process_data(items):
    result = []
    for item in items:
        if item is not None:
            if item != "":
                if item != "N/A":
                    result.append(item)
    return result

# Example 3: Poor Naming
def p(x):
    r = []
    for i in x:
        if i > 10:
            r.append(i * 2)
    return r

# Example 4: Inefficient Data Structure Usage
def check_duplicates(arr):
    duplicates = []
    for i in range(len(arr)):
        for j in range(i+1, len(arr)):
            if arr[i] == arr[j]:
                duplicates.append(arr[i])
    return duplicates